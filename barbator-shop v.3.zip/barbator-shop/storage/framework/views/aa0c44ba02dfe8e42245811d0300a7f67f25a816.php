

<?php $__env->startSection('title', 'Detail'); ?>;

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class= "row">
        <div class = "col-sm-6">
                <img class = "detail-img" src="<?php echo e($product->Photo); ?>" alt="No Image Found" style="height:400px">
        </div>
        <div class = "col-sm-6">
                <a href="javascript:javascript:history.go(-1)">Back</a>
                <h2><?php echo e($product->ProductName); ?></h2>
                <h3><?php echo e($category->CategoryName); ?></h3>
                <h3>Price : Rp. <?php echo e($product->Price); ?></h3>
                <h4>Description</h4>
                <p><?php echo e($product->Desc); ?></p>
                <br>
                <br>
               
                <h4>Qty</h4>
                <input type="text" name = "qty" id = "qty"> 
              
              
                <button class = "btn btn-primary">Add to Cart</button>
        </div>
          
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OneDrive - Bina Nusantara University\Lecture material\5TH SEMESTER\web programming\project lab\barbator-shop\resources\views/detail.blade.php ENDPATH**/ ?>