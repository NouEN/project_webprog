

<?php $__env->startSection('title', 'Category'); ?>;

<?php $__env->startSection('content'); ?>


<div class="row row-cols-1 row-cols-md-4 g-4 m-2">
	<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="col">
			<div class="card h-100 text-white text-center bg-dark mb-3" style="">
				<a href="detail/<?php echo e($product['id']); ?>">
					<img class="card-img-top" src=<?php echo e($product->Photo); ?> alt="Image Not Found" style="">
					<div class= card-body>
						<h5 class="card-title"><?php echo e($product->ProductName); ?></h5>
						<p class="card-text">Rp.<?php echo e(number_format($product->Price,0,'.','.')); ?></p>
					</div>
				</a>
			</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OneDrive - Bina Nusantara University\Lecture material\5TH SEMESTER\web programming\project lab\barbator-shop\resources\views/category.blade.php ENDPATH**/ ?>