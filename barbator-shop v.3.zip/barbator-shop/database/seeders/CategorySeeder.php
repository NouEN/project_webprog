<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('categories')->insert
        (
            ['CategoryName' => "Beauty"] 
        );


        DB::table('categories')->insert
        (
            ['CategoryName' => "Food and Beverages"] 
        );


        DB::table('categories')->insert
        (
            ['CategoryName' => "Camera"] 
        );

        DB::table('categories')->insert
        (
            ['CategoryName' => "Fashion"] 
        );

        DB::table('categories')->insert
        (
            ['CategoryName' => "Furniture"] 
        );
    }
}
