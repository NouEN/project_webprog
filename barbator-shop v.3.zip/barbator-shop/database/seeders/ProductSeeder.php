<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //FASHION PRODUCT START
        
        DB::table('products')->insert
        (
            ['category_id' => 4,
            'ProductName' => "Blazer Black",
            'Desc'=> "Basic things you need in everyday life",
            'Price' => 299000,
            'Photo' => 'https://image.uniqlo.com/UQ/ST3/AsianCommon/imagesgoods/425423/item/goods_69_425423.jpg?width=1600&impolicy=quality_75'
        ]
        );

        DB::table('products')->insert
        (
            ['category_id' => 4,
            'ProductName' => "Pink Waffle Sweater",
            'Desc'=> "Women's T-shirt in a softer waffle knit. Relaxed silhouette that goes well with a variety of bottoms",
            'Price' => 299000,
            'Photo' => 'https://image.uniqlo.com/UQ/ST3/AsianCommon/imagesgoods/449860/item/goods_11_449860.jpg?width=1600&impolicy=quality_75'
        ]
        );

        DB::table('products')->insert
        (
            ['category_id' => 4,
            'ProductName' => "Floral Dress",
            'Desc'=> "Make your life more lively with some floral patterns and pleated skirt.",
            'Price' => 899000,
            'Photo' => 'https://image.uniqlo.com/UQ/ST3/AsianCommon/imagesgoods/449556/item/goods_64_449556.jpg?width=1600&impolicy=quality_75'
        ]
        );

        DB::table('products')->insert
        (
            ['category_id' => 4,
            'ProductName' => "Black Waffle Pants Ultra Stretch",
            'Desc'=> "Stretchy pants to suit your body shape",
            'Price' => 299000,
            'Photo' => "https://image.uniqlo.com/UQ/ST3/AsianCommon/imagesgoods/445895/item/goods_09_445895.jpg?width=1600&impolicy=quality_75"
        ]
        );

        // FASHION PRODUCT END


        // BEAUTY PRODUCT START
        DB::table('products')->insert
        (
            ['category_id' => 1,
            'ProductName' => "Neutrogena Hydro Boost 3D Sleeping Mask",
            'Desc'=> "Membantu merawat kulit agar lebih sehat ideal, lembap, halus , dan bercahaya. Inovasi Moisture Sensor Complexnya dengan efektif mengembalikan kelembapan saat kamu paling membutuhkannya.",
            'Price' => 169200,
            'Photo' => "https://www.soco.id/cdn-cgi/image/w=150,format=auto,dpr=1.45/https://images.soco.id/82728552235-1599495419463.png"
        ]
        );

        DB::table('products')->insert
        (
            ['category_id' => 1,
            'ProductName' => "Carasun Solar Smart UV Protector SPF 45 PA++++ Sunscreen",
            'Desc'=> "Inovasi sunblock harian dari Carasun the Tropical Skin Expert!

            Solar Smart UV Protector melindungi optimal dengan SPF 45 yang menangkal 97.8% UVB, dan PA++++ perlindungan tertinggi terhadap UVA yang dapat memicu hyperpigmentasi dan penuaan dini.",
            'Price' => 55200,
            'Photo' => "https://images.soco.id/0a5e0c94-e945-4074-a705-6d819b84d743-53604992225-1615553749872.png"
        ]
        );


        DB::table('products')->insert
        (
            ['category_id' => 1,
            'ProductName' => "Rovectin Skin Essentials Cica Care Sleeping Pack",
            'Desc'=> "Rovectin Skin Essentials Cica Care Sleeping Mask merawat kulit Anda pada saat Anda tidur dan melembapkan kulit Anda. Dengan Centella Asiatica Extract yang terkandung di dalamnya, sleeping mask ini dapat membantu menjaga kulit Anda sepanjang malam.",
            'Price' => 210000,
            'Photo' => "https://s3-ap-southeast-1.amazonaws.com/img-sociolla/img/p/2/5/6/6/9/25669-large_default.jpg"
        ]
        );

        DB::table('products')->insert
        (
            ['category_id' => 1,
            'ProductName' => "Avoskin Miraculous Retinol Ampoule",
            'Desc'=> "Retinol ampoule pertama di Indonesia dengan kandungan Actosome Retinol yang mengandung 0,09% aktif Retinol. Dikombinasikan dengan 0,1% Hexapeptide, Vitamin E, Raspberry Extract, Pomegranate Extract, dan asam ellagic. Perpaduan tersebut membuat Miraculous Retinol Ampoule berfungsi optimal untuk membantu menunda munculnya tanda penuaan dini pada kulit dengan cara meningkatkan pergantian sel-sel kulit sehingga menjaga elastisitas dan kesehatan kulit.",
            'Price' => 287500,
            'Photo' => "https://images.soco.id/28397643509-1585554978331.png"
        ]
        );

        // BEAUTY PRODUCT END


        // FURNITURE PRODUCT START
        DB::table('products')->insert
        (
            ['category_id' => 5,
            'ProductName' => "AMaine Meja Kantor 120x60x75 Cm - Cokelat",
            'Desc'=> "Dapatkan kenyamanan selama berada di kantor dengan meja kantor dari Informa. Meja kerja ini dilengkapi dengan 2 laci di sisi kiri untuk menyimpan barang atau arsip. Di bagian atas meja ada lubang untuk kabel agar area kerja tetap rapi. Sisi depan meja ditambahkan kayu yang akan menutupi bagian bawah saat Anda duduk di belakang meja. Terbuat dari material MFC, dengan finishing melamine sehingga meja terlihat lebih elegan dan mudah dibersihkan.",
            'Price' => 1999000,
            'Photo' => "https://res.cloudinary.com/ruparupa-com/image/upload/w_360,h_360,f_auto,q_auto/f_auto,q_auto:eco/v1560758314/Products/10190254_2.jpg"
        ]
        );


        DB::table('products')->insert
        (
            ['category_id' => 5,
            'ProductName' => "Informa Oakland Sofa Tidur Fabric - Abu-abu",
            'Desc'=> "Keberadaan sofa tidur sangat fungsional untuk ruangan minimalis. Hanya dengan merebahkan bagian sandaran, Anda bisa mendapatkan tempat tidur yang nyaman digunakan. Desain sofa bernuansa modern minimalis, cocok mengisi berbagai sudut ruangan di rumah Anda.",
            'Price' => 999000,
            'Photo' => "https://res.cloudinary.com/ruparupa-com/image/upload/w_360,h_360,f_auto,q_auto/f_auto,q_auto:eco/v1636348026/Products/10396774_1.jpg"
        ]
        );

        DB::table('products')->insert
        (
            ['category_id' => 5,
            'ProductName' => "Lucca Tempat Tidur - Abu-abu/putih Oak",
            'Desc'=> "Lengkapi furnitur kamar Anda dengan Lucca tempat tidur istimewa satu ini. Hadir dengan desain minimalis dan fungsional, tempat tidur ini dilengkapi dengan kompartemen dan laci sehingga dapat digunakan sekaligus sebagai ruang penyimpanan tambahan pada kamar Anda. Tempat tidur ini memiliki aksen motif kayu oak dengan kombinasi warna-warna natural memberikan kesan modern yang menawan. Selain itu, tempat tidur ini memiliki konstruksi yang kokoh karena terbuat dari material berkualitas.",
            'Price' => 8799000,
            'Photo' => "https://res.cloudinary.com/ruparupa-com/image/upload/w_360,h_360,f_auto,q_auto/f_auto,q_auto:eco/v1650431942/Products/10293960_1.jpg"
        ]
        );

        DB::table('products')->insert
        (
            ['category_id' => 5,
            'ProductName' => "Kingswere Demarlos Laci Pakaian Kayu - Off-white",
            'Desc'=> "Tambahkan kesan menawan pada hunian Anda dengan menghadirkan laci kayu persembahan dari Kingswere. Dilengkapi dengan 9 buah laci, Anda dapat menyimpan ragam barang sehari-hari mulai dari pakaian, tas, dokumen, perhiasan, serta perlengkapan rumah tangga lainnya sesuai kebutuhan. Memiliki warna off-white yang netral, laci ini cocok untuk ditempatkan di kamar tidur ataupun ruang tamu Anda.",
            'Price' => 17499000,
            'Photo' => "https://res.cloudinary.com/ruparupa-com/image/upload/w_360,h_360,f_auto,q_auto/f_auto,q_auto:eco/v1609169721/Products/10425282_1.jpg"
        ]
        );

        DB::table('products')->insert
        (
            ['category_id' => 5,
            'ProductName' => "Ashley Lemari Bolanburg",
            'Desc'=> "Bolanburg Lemari dari Ashley hadir dengan desain vintage yang tentunya dapat membawa nuansa baru pada dekorasi ruang keluarga Anda. Piagam penghargaan, koleksi buku, hingga pajangan favorit bisa Anda tata rapi di kabinet ini. ",
            'Price' => 7999000,
            'Photo' => "https://res.cloudinary.com/ruparupa-com/image/upload/w_360,h_360,f_auto,q_auto/f_auto,q_auto:eco/v1562781495/Products/10092787_1.jpg"
        ]
        );

        // FURNITURE PRODUCT END

        // FOOD AND BEVERAGES PRODUCT START

        DB::table('products')->insert
        (
            ['category_id' => 2,
            'ProductName' => "Ichitan Yoghurt Calvit Japanese Strawberry Style 250mL",
            'Desc'=> "Ichitan Yoghurt Calvit Japanese Strawberry Style 250mL",
            'Price' => 7000,
            'Photo' => "https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcStGX34jkKV0Jfn6YCKtj1iCgzY4MQdifJe7z0SY8JwgZ-wbfFeFbyAkI1zrP05K1wyy_V4qVHKdvjYvEbBDhizKOBudqeZkLBctdOqXK8zENgbslEO8Akjxw&usqp=CAE"
        ]
        );

        DB::table('products')->insert
        (
            ['category_id' => 2,
            'ProductName' => "Cheetos Crunchy Flamin' Hot 226 Gr",
            'Desc'=> "Cheetos Crunchy Flamin' Hot 226 Gr",
            'Price' => 110900,
            'Photo' => "https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcQbe8WQLifAKFui59V2ElfXchEXmnYsYzSOE23za9LOa0tkD_R82N7avimwA8w3mCdkAxlv2qbuOyzuISTAzP5JuMunr5MoqUfIIB3HjmaIQkLyE9Nt7ChJ&usqp=CAE"
        ]
        );

        DB::table('products')->insert
        (
            ['category_id' => 2,
            'ProductName' => "Tropicana Slim Hokkaido Cheese Cookies (5 SCH)",
            'Desc'=> "Tropicana Slim Hokkaido Cheese Cookies adalah varian kedua dari Tropicana Slim Sugar Free Cookies yang merupakan cookies sehat bebas gula dengan perpaduan gurihnya keju Hokkaido dan manisnya Tropicana Slim. Rasanya yang lezat namun bebas gula menjadikan cookies ini sebagai alternatif anda yang sedang menjaga kadar gula darah",
            'Price' => 18700,
            'Photo' => "https://ik.imagekit.io/z83ycl28q/media/catalog/product/cache/206d6ebf3fdb585a5f4836aede302e61/h/o/hokkaido_cheese_1.jpg"
        ]
        );

        DB::table('products')->insert
        (
            ['category_id' => 2,
            'ProductName' => "Tropicana Slim Mint Cocoa (10 Sch) - Minuman Cokelat Mint Nikmat Tanpa Gula Pasir",
            'Desc'=> "Tropicana Slim Mint Cocoa, minuman cokelat dengan sensasi mint yang nikmat. Tanpa penambahan gula pasir, cocok untuk yang ingin membatasi asupan gula harian",
            'Price' => 39200,
            'Photo' => "https://ik.imagekit.io/z83ycl28q/media/catalog/product/cache/206d6ebf3fdb585a5f4836aede302e61/s/i/single_-_tropicana_slim_mint_cocoa_10_sch.jpg"
        ]
        );

        // FOOD AND BEVERAGES PRODUCT END


        // CAMERA PRODUCT START
        DB::table('products')->insert
        (
            ['category_id' => 3,
            'ProductName' => "FUJIFILM INSTAX MINI 11 Instant Film Camera (Lilac Purple)",
            'Desc'=> "A fresh take on a beloved instant film camera, the lilac purple FUJIFILM INSTAX MINI 11 is a sleek, fun, and stylish camera capable of producing instant credit card-sized prints. This model has been updated with an automatic exposure function that no longer requires manual adjustment for different lighting conditions, and the built-in flash benefits working in low-light conditions.",
            'Price' => 932817,
            'Photo' => "https://www.bhphotovideo.com/cdn-cgi/image/format=auto,fit=scale-down,width=500,quality=95/https://www.bhphotovideo.com/images/images500x500/fujifilm_16654803_instax_mini_11_instant_1582663926_1548524.jpg"
        ]
        );

        DB::table('products')->insert
        (
            ['category_id' => 3,
            'ProductName' => "Sony a7R V Mirrorless Camera",
            'Desc'=> "Combining resolution and precision, the Sony a7R V is the mirrorless camera designed for those who crave detail. Featuring a 61MP full-frame sensor, all-new AI-based autofocus system with advanced subject recognition, 8K video recording, and 8-stop image stabilization, the fifth-generation a7R is reliable and well-rounded for both photography and video applications.",
            'Price' => 60601905,
            'Photo' => "https://www.bhphotovideo.com/cdn-cgi/image/format=auto,fit=scale-down,width=500,quality=95/https://www.bhphotovideo.com/images/images500x500/sony_alpha_camera_1666779545_1731389.jpg"
        ]
        );

        DB::table('products')->insert
        (
            ['category_id' => 3,
            'ProductName' => "Canon EOS Rebel T100 DSLR Camera with 18-55mm Lens",
            'Desc'=> "Mixing a sleek design with essential capabilities, the Canon EOS Rebel T100 is a capable DSLR suitable for both photo and video shooting. The proven 18MP sensor design offers impressive image quality and sensitivity, along with 3 fps continuous shooting and up to Full HD 30p video recording. Also, the familiar DSLR design incorporates an optical viewfinder for clear, intuitive viewing and the body also sports a rear LCD along with built-in Wi-Fi for on-the-go sharing.",
            'Price' => 4661685,
            'Photo' => "https://www.bhphotovideo.com/cdn-cgi/image/format=auto,fit=scale-down,width=500,quality=95/https://www.bhphotovideo.com/images/images500x500/canon_2628c029_eos_rebel_t100_dslr_1670509529_1719262.jpg"
        ]
        );

        DB::table('products')->insert
        (
            ['category_id' => 3,
            'ProductName' => "Nikon Z6 II Mirrorless Camera",
            'Desc'=> "More speed, more versatility, more performance, the Nikon Z6 II is an updated take on the all-rounder mirrorless camera designed for high-end photo and video applications. Despite the wealth of upgrades, the Z6 II retains its familiar form factor and prized image quality to benefit working multimedia image-makers.",
            'Price' => 26416215,
            'Photo' => "https://www.bhphotovideo.com/cdn-cgi/image/format=auto,fit=scale-down,width=500,quality=95/https://www.bhphotovideo.com/images/images500x500/nikon_z_6_ii_mirrorless_1602636707_1597167.jpg"
        ]
        );

        // CAMERA PRODUCT END

    }
}
