<?php

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\RegisterController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/welcome', function () {
    return view('welcome');
});

Route::get('/', [ProductController::class, 'viewHomePage']);
Route::get('/login', [Controller::class, 'showLoginPage']);
Route::get('/register', [RegisterController::class, 'showRegisterPage']);

Route::post('/register', [RegisterController::class, 'storeUserData']);
Route::get('/view/search', [ProductController::class, 'viewSearchPage']);

Route::get('detail/{id}', [ProductController::class, 'viewDetailPage']);

Route::get('category/{id}', [ProductController::class, 'viewCategoryPage']);

Route::get('category/detail/{id}', [ProductController::class, 'viewDetailPage']);