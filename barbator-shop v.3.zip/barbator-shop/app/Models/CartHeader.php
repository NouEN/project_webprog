<?php

namespace App\Models;

use App\Models\User;
use App\Models\CartDetail;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class CartHeader extends Model
{
    use HasFactory;
    PUBLIC $timestamps = false;

    public function detail(){
        return $this->hasOne(CartDetail::class, "cart_id", "id");
    }


    public function user()
    {
        return $this->belongsTo(User::class,"users_id", "id");
    }
}
