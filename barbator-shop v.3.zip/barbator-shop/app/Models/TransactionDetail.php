<?php

namespace App\Models;

use App\Models\TransactionHeader;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class TransactionDetail extends Model
{
    use HasFactory;
    PUBLIC $timestamps = FALSE;

    public function header()
    {
        return $this->belongsTo(TransactionHeader::class,"transaction_id", "id");
    }
}
