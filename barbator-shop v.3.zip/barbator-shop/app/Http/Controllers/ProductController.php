<?php

namespace App\Http\Controllers;
use App\Models\Product;
use App\Models\Category;
use Illuminate\Http\Request;
use DB;

class ProductController extends Controller
{
    //
    public function viewHomePage()
    {
       
        $products = Product::has("category")->simplePaginate(10);
        
        
        return view('home')->with('products', $products);
    }

    public function viewSearchPage(Request $request)
    {
        $products = Product::where('ProductName', 'LIKE', "%$request->search%")->simplePaginate(10);

        return view('home')->with('products', $products);
    }

    public function viewCategoryPage($category_id)
    {

        $categoryProduct = Product::where('category_id', '=', "$category_id")->simplePaginate(10);
       
       return view('home')->with('products', $categoryProduct);
    }


    public function viewDetailPage($id)
    {
        $data = Product::find($id);
        
       $categoryName = Category::find($data->category_id);


        return view('detail', ['product'=> $data, 'category'=> $categoryName]); 
    }
}
