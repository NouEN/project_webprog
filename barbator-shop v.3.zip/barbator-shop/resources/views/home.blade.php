@extends('navbar')

@section('title', 'Home');

@section('content')

<form style = "margin : 50px" class = "d-flex" action="{{url('/view/search')}}">
	<input class="form-control me-2" type="search" placeholder = "Search" aria-label = "Search" name = "search">
	<button class="btn btn-outline-success" type="submit">
		Search
	</button>
</form>

<h2>All Items</h2>
<div class="row row-cols-1 row-cols-md-4 g-4 m-2">
	@foreach($products as $product)
		<div class="col">
			<div class="card h-100 text-white text-center bg-dark mb-3" style="">
				<a href="detail/{{$product['id']}}">
					<img class="card-img-top" src={{$product->Photo}} alt="Image Not Found" style="">
					<div class= card-body>
						<h5 class="card-title">{{$product->ProductName}}</h5>
						<p class="card-text">Rp.{{number_format($product->Price,0,'.','.')}}</p>
					</div>
				</a>
			</div>
		</div>
	@endforeach
</div>

<div class="m-5 d-flex justify-content-center">
	{{ $products->withQueryString()->links() }}
</div>
@endsection