@extends('navbar')

@section('title', 'Detail');

@section('content')

    <div class="container">
        <div class= "row">
        <div class = "col-sm-6">
                <img class = "detail-img" src="{{$product->Photo}}" alt="No Image Found" style="height:400px">
        </div>
        <div class = "col-sm-6">
                <a href="javascript:javascript:history.go(-1)">Back</a>
                <h2>{{$product->ProductName}}</h2>
                <h3>{{$category->CategoryName}}</h3>
                <h3>Price : Rp. {{$product->Price}}</h3>
                <h4>Description</h4>
                <p>{{$product->Desc}}</p>
                <br>
                <br>
               
                <h4>Qty</h4>
                <input type="text" name = "qty" id = "qty"> 
              
              
                <button class = "btn btn-primary">Add to Cart</button>
        </div>
          
        </div>
    </div>
@endsection