

<?php $__env->startSection('title', 'Home'); ?>;

<?php $__env->startSection('content'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OneDrive - Bina Nusantara University\Lecture material\5TH SEMESTER\web programming\project lab\barbator-shop\resources\views/home.blade.php ENDPATH**/ ?>