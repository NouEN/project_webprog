@extends('navbar')

@section('title', 'Home');

@section('content')


@endsection