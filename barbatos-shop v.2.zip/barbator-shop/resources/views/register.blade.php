@extends('navbar')

@section('title', 'Register')

@section('content')

<h2>Register</h2>   
<div class="d-flex justify-content-center align-content-center" style="margin-top: 50px">     
<form action="/register" method="post">
            {{ csrf_field() }}
            <div class="mb-3">
              <label for="name" class="form-label">Name</label>
              <input type="text" name="name" class="form-control @error('name') is-invalid @enderror" id="name" placeholder="Enter Your Name" required>
              @error('name')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
            @enderror
            </div>
            
            <div class="mb-3">
              <label for="email" class="form-label">Email</label>
              <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" id="email" name="email" placeholder="Enter Your Email" aria-describedby="emailHelp" required>
                @error('email')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
                @enderror
            </div>

            <div class="mb-3">
              <label for="password" class="form-label">Password</label>
              <input type="password" name = "password" class="form-control @error('password') is-invalid @enderror" id="password" name="password" placeholder="Enter Your Password" required>
              @error('password')
                <div class="invalid-feedback">
                 {{ $message}}
                </div>
                @enderror
            </div>



            <div class="mb-3">
              <label for="confirmPassword" class="form-label">Confirm Password</label>
              <input type="password" name = "confirmPassword" class="form-control @error('confirmPassword') is-invalid @enderror" id="confirmPassword" name="confirmPassword" placeholder="Re-type Your Password" required>
              @error('confirmPassword')
                <div class="invalid-feedback">
                 {{ $message}}
                </div>
            @enderror
        
            </div>
            <div class="mb-3">
                <label for="">Gender</label>
                <div class = "mb-3 form-check"> 
                    <input class="form-check-input @error('gender') is-invalid @enderror" type="radio" name="gender" id="male" required >
                    <label class="form-check-label" for="male">
                        Male
                    </label>
                </div>
                <div class = "mb-3 form-check"> 
                    <input class="form-check-input @error('gender') is-invalid @enderror" type="radio" name="gender" id="female" required>
                    <label class="form-check-label" for="female">
                        Female
                    </label>
                </div>

                @error('gender')
                <div class="invalid-feedback">
                 {{ $message}}
                </div>
                @enderror
            </div>
            



            <div class="mb-3">
            <label for="dob" class="form-label">Date of Birth</label>
            <input class="date form-control @error('dob') is-invalid @enderror" type="text" name = "dob" id = "dob" placeholder = "Date of Birth" required>
        </div>
        
        <script type="text/javascript" >
            $('.date').datepicker();  
        </script> 

            @error('dob')
                <div class="invalid-feedback">
                 {{ $message}}
                </div>
                @enderror
    



            <div class = "mb-3">
                <label for="country">Country</label>
                <select class="form-select @error('country') is-invalid @enderror" name = "country" id="country" required>
                    <option value="">Choose A Country</option>
                    <option value="indonesia">Indonesia</option>
                    <option value="2">Two</option>
                    <option value="3">Three</option>
                </select>
                
                @error('country')
                <div class="invalid-feedback">
                 {{ $message}}
                </div>
                @enderror

            </div>
            
            <button type="submit" class="btn btn-primary">Register</button>
            <div>
            <p>Have an account?</p>
            <a href="/login">Login here</a>
        </div>
        </form>   
        
        
  
    </div>

   
    @if($errors->any())
        <strong style = "color:red">{{$errors->first()}}</strong>
    @endif


@endsection

