<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class RegisterController extends Controller
{
    public function showRegisterPage()
    {
        return view('register');
    }

    public function storeUserData(Request $request)
    {
       
        $request->validate([
            'name'=>'required|min:5',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:8|alpha_num',
            'confirmPassword' => 'required|same:password',
            'gender' => 'required',
            'dob' => 'required|before:today|after:01/01/1900',
            'country'=> 'required'

        ]);
      
       $user = new User();
       $user->UserName = $request->name;
       $user->Email = $request->email;
       $user->Password = $request->password;
       $user->Gender = $request->gender;
       $user->DOB = $request->dob;
       $user->Country = $request->country;

        return redirect('/login');

    }
}
